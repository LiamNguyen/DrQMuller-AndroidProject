<?php
$server   = "127.0.0.1";
$database = "test";
$username = "root";
$password = "";

// Data to get from Android
$LOGIN_ID = "TEST_USERNAME"; //GET FROM TEXTFIELD
$PASSWORD = "TEST_PASSWORD"; //GET FROM TEXTFIELD

// Create connection
$con = mysqli_connect($server,$username,$password,$database);
$JSONdata = array();

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT CUSTOMER_ID FROM test.tbl_Customers WHERE LOGIN_ID = '" . $LOGIN_ID . "' AND PASSWORD = '" . $PASSWORD . "'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {

    // output data of each row
    echo "" . mysqli_num_rows($result);
} else {
    echo "0";
}

mysqli_close($con);
?>